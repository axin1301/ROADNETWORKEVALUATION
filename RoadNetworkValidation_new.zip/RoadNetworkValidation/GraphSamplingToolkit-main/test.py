import math
import numpy as np

print(1 / np.cos(39.96512652903208 * np.pi / 180))