# import geopandas as gpd
import pandas as pd
import numpy as np
from shapely.geometry import Point
from PIL import Image
import PIL
PIL.Image.MAX_IMAGE_PIXELS = None
from skimage import morphology,draw
import cv2
import matplotlib.pyplot as plt


road = Image.open('xiaoxian_GT_primary.png')
print(np.array(road).shape)

road_seg = np.array(road)#[30000:40000,30000:40000]
road_idx = np.where(road_seg > 0)
bin_image = np.zeros((road_seg.shape[0],road_seg.shape[1]))
bin_image[road_idx[0],road_idx[1]] = 1

bin_image = np.uint8(bin_image)
test_img = bin_image

_, labels, stats, centroids = cv2.connectedComponentsWithStats(bin_image)
print(centroids)
print("stats",stats)
i=0
for istat in stats:
    if istat[4]<5000:
        #print(i)
        # print(istat[0:2])
        if istat[0]<=5000 and istat[1]<=5000 and istat[0]+istat[2]>=50000 and istat[1]+istat[3]>=50000:
            print(tuple(istat[0:2]),tuple(istat[0:2]+istat[2:4]))
            continue
        # if istat[3]>istat[4]:
        #     r=istat[3]
        # else:r=istat[4]
        cv2.rectangle(test_img,tuple(istat[0:2]),tuple(istat[0:2]+istat[2:4]) , 0,thickness=-1)  # 26
    i=i+1

# plt.imshow(test_img)
# plt.show()

kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (25,25))
bin_image = cv2.morphologyEx(test_img, cv2.MORPH_CLOSE, kernel)

image = bin_image

print(image.shape)
#实施骨架算法
skeleton =morphology.skeletonize(image)
skeleton = Image.fromarray(skeleton)
skeleton.convert('L').save('DeepMG-master/topology_construction/test_rn_GT_full.png')  #xiaoxian