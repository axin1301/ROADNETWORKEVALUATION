class MapMatcher:
    def __init__(self, rn, routing_weight='length'):
        self.rn = rn
        self.routing_weight = routing_weight

    def match(self, traj):
        pass

    def match_to_path(self, traj):
        pass
