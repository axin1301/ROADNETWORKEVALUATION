import os
from PIL import Image
import pandas as pd
import math
import numpy as np
import geopandas as gpd
import PIL.Image
import cv2
PIL.Image.MAX_IMAGE_PIXELS = None
import matplotlib.pyplot as plt
import glob

def deg2num(lat_deg, lon_deg, zoom):
    lat_rad = math.radians(lat_deg)
    n = 2.0 ** zoom
    xtile = int((lon_deg + 180.0) / 360.0 * n)
    ytile = int((1.0 - math.log(math.tan(lat_rad) + (1 / math.cos(lat_rad))) / math.pi) / 2.0 * n)
    return (xtile, ytile)

def num2deg(xtile, ytile, zoom):
    n = 2.0 ** zoom
    lon_deg = xtile / n * 360.0 - 180.0
    lat_rad = math.atan(math.sinh(math.pi * (1 - 2 * ytile / n)))
    lat_deg = math.degrees(lat_rad)
    return (lat_deg, lon_deg)

def point2geo0(p1, p2, im_height, im_width, para0, para1, para3, para5):
    delta_x = int((p1 - para0)/para1)
    delta_y = int((p2 - para3)/para5)

    if delta_y <im_height and delta_x<im_width:
            # if np.sum(im_data[:,delta_y,delta_x])<0:
                    # break
        return delta_y
    else:
        return -1
        
def point2geo1(p1, p2, im_height, im_width, para0, para1, para3, para5):
    delta_x = int((p1 - para0)/para1)
    delta_y = int((p2 - para3)/para5)

    if delta_y <im_height and delta_x<im_width:
        # if np.sum(im_data[:,delta_y,delta_x])<0:
                # break
        return delta_x
    else:
        return -1


city = 'xiaoxian'
year = 2020
xiaoxian_road_GT_file = 'driving_road_xiaoxian_0_2020.geojson'

pd_dict_GT = pd.read_csv(city+'.csv')

img_name_list_all_GT = []
for i in range(len(pd_dict_GT)):
    img_name_list_all_GT.append(str(pd_dict_GT.at[i,'y_tile'])+'_'+str(pd_dict_GT.at[i,'x_tile']))


osm_road = gpd.read_file(xiaoxian_road_GT_file)

# osm_road_new = osm_road.loc[osm_road['name']=='教育路']#26143, 54054

# osm_road_new = osm_road[osm_road['name']=='世纪大道'] #26142, 54049

for road_idx in range(len(osm_road)): ###################original geojson
    geo1 = osm_road.at[road_idx,'geometry']  #每一条路先制成一个label， geometry为一个lon,lat list
    road_name = osm_road.at[road_idx,'id']
    # if road_name!=225534870:
    #     continue
    print(road_name)
    geo1= list(geo1.geoms)
    point_list = []

    for g in geo1:
        for point in g.coords:
            point_list.append(point)
    # print(len(point_list))
    # print(point_list[:10])

    p1_list = [x[0] for x in point_list]
    p2_list = [x[1] for x in point_list]

    min_p1 = min(p1_list)
    max_p1 = max(p1_list)
    min_p2 = min(p2_list)
    max_p2 = max(p2_list)
    print(min_p2, max_p2, min_p1, max_p1)

    min_x_tmp,min_y_tmp = deg2num(max_p2,min_p1,16)
    max_x_tmp,max_y_tmp = deg2num(min_p2,max_p1,16)

    min_x = min_x_tmp
    min_y = min_y_tmp
    
    max_x = max_x_tmp+1
    max_y = max_y_tmp+1
    print(min_y, max_y, min_x, max_x)

    top_left_lat, top_left_lng = num2deg(min_x, min_y, 16)
    bottom_right_lat, bottom_right_lng = num2deg(max_x+1, max_y+1, 16)

    mask_width_now = max_x-min_x+1
    mask_height_now = max_y-min_y+1

    mask_width = mask_width_now
    mask_height = mask_height_now
    print(mask_height, mask_width)

    delta_lng = (bottom_right_lng - top_left_lng)/mask_width/512
    delta_lat = (bottom_right_lat - top_left_lat)/mask_height/512

    pd_dict = pd.DataFrame({'p1': p1_list, 'p2': p2_list})
    pd_dict.drop_duplicates(subset = ['p1','p2'], inplace = True)
    # pd_dict.to_csv('ss/point_file.csv', index = False)

    # 0,3 左上角位置
    # 1 像元宽度
    # 5 像元高度
    para = [top_left_lng,delta_lng,0, top_left_lat,0,delta_lat]
    im_height = mask_height*512
    im_width = mask_width*512

    pd_dict['row'] = 0
    pd_dict['col'] = 0

    pd_dict['row'] = pd_dict.apply(lambda x: point2geo0(x['p1'], x['p2'], \
                im_height, im_width, para[0], para[1], para[3], para[5]), axis = 1)
    pd_dict['col'] = pd_dict.apply(lambda x: point2geo1(x['p1'], x['p2'], \
                im_height, im_width, para[0], para[1], para[3], para[5]), axis = 1)
    pd_dict.drop_duplicates(subset = ['row','col'], inplace = True)
    print(len(pd_dict))
    pd_dict_new = pd_dict.drop(pd_dict[(pd_dict['row']<0) | (pd_dict['col']<0)|
                                    (pd_dict['row']>=im_height) | (pd_dict['col']>=im_width)].index)

    label_array = np.zeros((im_height, im_width))

    pd_dict_new = pd_dict_new.reset_index(drop = True)

    for k in range(len(pd_dict_new)-1):
        print((pd_dict_new.at[k,'row'],pd_dict_new.at[k,'col']), (pd_dict_new.at[k+1,'row'],pd_dict_new.at[k+1,'col']))
        label_array = cv2.line(label_array, (pd_dict_new.at[k,'col'],pd_dict_new.at[k,'row']), (pd_dict_new.at[k+1,'col'], \
                                                                                                pd_dict_new.at[k+1,'row']), (255, 255, 0), 3) #start_point, end_point, color, thickness


    #####################OSM label line color image

    for i in range(mask_height):
        for j in range(mask_width):
            img_name = str(i+min_y)+'_'+str(j+min_x)

            if img_name not in img_name_list_all_GT:
                continue

            if np.sum(label_array[(i)*512:(i+1)*512, (j)*512:(j+1)*512])==0:
                continue

            im = Image.fromarray((label_array[(i)*512:(i+1)*512, (j)*512:(j+1)*512]))
            im.convert('L').save('xiaoxian_width3/'+city+ '_' + str(year) + '_OSM_road_label_'+str(road_name)+'_'+img_name+'.png')


##############################将同属于一张图像的所有路网综合起来
pd_dict = pd.read_csv(city+'.csv')

label_list = glob.glob('xiaoxian_width3/*.png')

label_img_list = [x.split('.')[0].split('_',7)[-1] for x in label_list]

print(label_img_list[:5])

for k in range(len(pd_dict)):
    y_tile = pd_dict.at[k,'y_tile']
    x_tile = pd_dict.at[k,'x_tile']
    img_name = str(y_tile)+'_'+str(x_tile)
    print(img_name)
    # img_name = '26174_54068'

    b = []
    for index, nums in enumerate(label_img_list):
        if nums == str(img_name):
            b.append(index)
    print(b)

    if len(b)==0:
        continue

    if len(b) > 1:
        label_img = np.array(Image.open(label_list[b[0]]))
        for j in b[1:]:
            label_img_tmp = np.array(Image.open(label_list[j]))
            label_img = label_img+label_img_tmp
        label_img[label_img>0] = 255
    else:
        label_img = np.array(Image.open(label_list[b[0]]))
        label_img[label_img>0] = 255

    im = Image.fromarray(label_img)            
    im.convert('L').save('xiaoxian_road_label_by_image/'+img_name+'.png')  #xiaoxian