import os

os.system('python shp2txt_transform.py --district xixiangxian --year 2017')
os.system('python shp2txt_transform.py --district xixiangxian --year 2019')
os.system('python shp2txt_transform.py --district xixiangxian --year 2021')
os.system('python shp2txt_transform.py --district xixiangxian --year 2023')

os.system('python shp2txt_transform.py --district danfengxian  --year 2017')
os.system('python shp2txt_transform.py --district danfengxian --year 2019')
os.system('python shp2txt_transform.py --district  danfengxian --year 2021')
os.system('python shp2txt_transform.py --district  danfengxian --year 2023')

# os.system('python shp2txt_transform.py --district fuqingshi  --year 2017')
# os.system('python shp2txt_transform.py --district fuqingshi --year 2019')
# os.system('python shp2txt_transform.py --district fuqingshi --year 2021')
# os.system('python shp2txt_transform.py --district fuqingshi --year 2023')

os.system('python shp2txt_transform.py --district gaoyoushi --year 2017')
os.system('python shp2txt_transform.py --district gaoyoushi --year 2019')
os.system('python shp2txt_transform.py --district gaoyoushi --year 2021')
os.system('python shp2txt_transform.py --district gaoyoushi --year 2023')

os.system('python shp2txt_transform.py --district guanghexian --year 2017')
os.system('python shp2txt_transform.py --district guanghexian --year 2019')
os.system('python shp2txt_transform.py --district guanghexian --year 2021')
os.system('python shp2txt_transform.py --district guanghexian --year 2023')

os.system('python shp2txt_transform.py --district honghexian --year 2017')
os.system('python shp2txt_transform.py --district honghexian --year 2019')
os.system('python shp2txt_transform.py --district honghexian --year 2021')
os.system('python shp2txt_transform.py --district honghexian --year 2023')

os.system('python shp2txt_transform.py --district jiangzixian --year 2017')
os.system('python shp2txt_transform.py --district jiangzixian --year 2019')
os.system('python shp2txt_transform.py --district jiangzixian --year 2021')
os.system('python shp2txt_transform.py --district jiangzixian --year 2023')

os.system('python shp2txt_transform.py --district jingyuxian --year 2017')
os.system('python shp2txt_transform.py --district jingyuxian --year 2019')
os.system('python shp2txt_transform.py --district jingyuxian --year 2021')
os.system('python shp2txt_transform.py --district jingyuxian --year 2023')

os.system('python shp2txt_transform.py --district jinjiangshi --year 2017')
os.system('python shp2txt_transform.py --district jinjiangshi --year 2019')
os.system('python shp2txt_transform.py --district jinjiangshi --year 2021')
os.system('python shp2txt_transform.py --district jinjiangshi --year 2023')

os.system('python shp2txt_transform.py --district kunshanshi --year 2017')
os.system('python shp2txt_transform.py --district kunshanshi --year 2019')
os.system('python shp2txt_transform.py --district kunshanshi --year 2021')
os.system('python shp2txt_transform.py --district kunshanshi --year 2023')

os.system('python shp2txt_transform.py --district liboxian --year 2017')
os.system('python shp2txt_transform.py --district liboxian --year 2019')
os.system('python shp2txt_transform.py --district liboxian --year 2021')
os.system('python shp2txt_transform.py --district liboxian --year 2023')

os.system('python shp2txt_transform.py --district linquanxian --year 2017')
os.system('python shp2txt_transform.py --district  linquanxian --year 2019')
os.system('python shp2txt_transform.py --district linquanxian  --year 2021')
os.system('python shp2txt_transform.py --district linquanxian  --year 2023')

os.system('python shp2txt_transform.py --district pinghushi --year 2017')
os.system('python shp2txt_transform.py --district pinghushi --year 2019')
os.system('python shp2txt_transform.py --district pinghushi --year 2021')
os.system('python shp2txt_transform.py --district pinghushi --year 2023')

os.system('python shp2txt_transform.py --district shufuxian --year 2017')
os.system('python shp2txt_transform.py --district shufuxian --year 2019')
os.system('python shp2txt_transform.py --district  shufuxian --year 2021')
os.system('python shp2txt_transform.py --district shufuxian --year 2023')

os.system('python shp2txt_transform.py --district zhangjiagangshi --year 2017')
os.system('python shp2txt_transform.py --district zhangjiagangshi --year 2019')
os.system('python shp2txt_transform.py --district zhangjiagangshi --year 2021')
os.system('python shp2txt_transform.py --district zhangjiagangshi --year 2023')